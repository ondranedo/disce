#ifndef AUTA_LIB_H
#define AUTA_LIB_H
#include <stdio.h>

class Auto{
private:
	int MrokVyroby = 0;
	char* Mmodel = nullptr;
	int MmodelLen = 0;
	
public:
	Auto(int rokVyroby,const char* model);
	void printInfo();
	Auto(const char* filename,int index);
	Auto(FILE* file);
	void appendToBin(const char* filename);
	~Auto();
};



#endif
