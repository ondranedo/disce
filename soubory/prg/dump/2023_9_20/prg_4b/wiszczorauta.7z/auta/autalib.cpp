#include "autalib.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

Auto::Auto(int rokVyroby,const char* model){
		MrokVyroby = rokVyroby;
		MmodelLen = strlen(model) + 1;
		Mmodel = (char*)malloc(MmodelLen);
		strcpy(Mmodel, model);
};
void Auto::printInfo(){
	printf("Model: %s, rok: %d\n", Mmodel, MrokVyroby);
}
Auto::Auto(const char* filename,int index){
	FILE* file = fopen(filename, "rb");
	int entries;
	if(!file){
		fclose(file);
		return;
	}
	int strlength;
	
	fread(&entries, sizeof(int), 1, file);
	if(index >= entries){
		index = entries - 1;
	}
	
	for(int i = 0; i < index; i++){
		fseek(file,sizeof(int) ,SEEK_CUR);
		fread(&strlength, sizeof(int), 1, file);
		fseek(file, strlength, SEEK_CUR);
	}
	
	fread(&MrokVyroby, sizeof(int), 1 , file);
	fread(&MmodelLen, sizeof(int), 1 , file);
	Mmodel = (char*)malloc(MmodelLen);
	fread(Mmodel, 1, MmodelLen, file);
	
	fclose(file);
}
void Auto::appendToBin(const char* filename){
	FILE* file = fopen(filename, "ab");
	
	fwrite(&MrokVyroby, sizeof(int), 1, file);
	fwrite(&MmodelLen, sizeof(int), 1, file);
	fwrite(Mmodel, 1, MmodelLen, file);
	
	fclose(file);
}
Auto::~Auto(){
	free(Mmodel);
}

Auto::Auto(FILE* file){	
	fread(&MrokVyroby, sizeof(int), 1 , file);
	fread(&MmodelLen, sizeof(int), 1 , file);
	Mmodel = (char*)malloc(MmodelLen);
	fread(Mmodel, 1, MmodelLen, file);
}
