#include "autalib.h"
#include <stdlib.h>
#include <stdio.h>

#define FILENAME "auta.adam"
//nefunkcni

int main(){
	int pocetAut = 0;
	FILE* file;
	char* model = (char*)malloc(1024);
	int rok;
	int volba;
	char work = 1;
	
	while(work){
		printf("1 - Vypsat auta ze souboru\n");
		printf("2 - Pridat auto do souboru\n");
		printf("3 - Vypis konkretniho modelu\n");
		printf("ostatni - konec\n");
		scanf("%d", &volba);
		
		switch (volba) {
		case 1:
				file = fopen(FILENAME, "rb");
				if(!file){
					printf("Soubor nenalezen, vytvorte ho pridanim jednoho auta\n");
				}
				else{
					fread(&pocetAut, sizeof(int), 1, file);
					for(int i = 0; i < pocetAut; i++){
						
						Auto temp(FILENAME, i);
						temp.printInfo();
						
					}
				}
				fclose(file);
			break;
		case 2:
			file = fopen(FILENAME, "rb");
			if(file){
				fread(&pocetAut, sizeof(int), 1, file);
			}
			fclose(file);
			
			file = fopen(FILENAME, "wb");
			pocetAut++;
			fwrite(&pocetAut, sizeof(int), 1, file);
			fclose(file);
			
			fflush(stdin);
			printf("Zadejte nazev auta: ");
			gets(model);
			printf("Zadejte rok vyroby auta: ");
			scanf("%d", &rok);
			{
			Auto a(rok, model);
			a.appendToBin(FILENAME);
			}
			
			break;
		case 3:
			{
				printf("Zadejte index pro vypis: ");
				scanf("%d", &rok);
				Auto a(FILENAME, rok);
				a.printInfo();
			}
			break;
		default:
			work = 0;
			break;
		}
	}
	
	
	free(model);
	system("pause");
	return 0;
}
