#include "autadva.h"
#include <stdio.h>
#include <stdlib.h>

int main(){
	
	int volba;
	T_auto temp;
	int rokVyroby;
	char* nazev = (char*)malloc(1000);
	char pokracuj = 1;
	
	printf("Razeni nefunguje ale aspon soubor ano");
	while(pokracuj){
		printf("1 - Vypis aut ze souboru\n");
		printf("2 - Seradit soubor podle jmena vzestupne\n");
		printf("3 - Seradit soubor podle jmena sestupne\n");
		printf("4 - Seradit soubor podle roku vzestupne\n");
		printf("5 - Seradit soubor podle roku sestupne\n");
		printf("6 - Nove auto na konec souboru\n");
		printf("7 - Vypis konkretniho auta\n");
		printf("Cokoli jineho - konec\nVolba: ");
		scanf("%d", &volba);
		switch (volba) {
			
			case 1:
				vypsatAutaZeSouboru();
				break;
			case 2:
				//TODO
				break;
			case 3:
				//TODO
				break;
			case 4:
				//TODO
				break;
			case 5:
				//TODO
				break;
			case 6:
				printf("Zadejte nazev auta: ");
				fflush(stdin);
				gets(nazev);
				printf("Zadejte rok vyroby: ");
				scanf("%d", &rokVyroby);
				temp = noveAuto(rokVyroby, nazev);
				pridatAutoDoSouboru(temp);
				free(temp.nazev);
				break;
			case 7:
				//TODO
				break;
			default:
				pokracuj = 0;
				break;
		}
	}
	free(nazev);
	system("pause");
	return 0;
}
