#include "autadva.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void pridatAutoDoSouboru(T_auto a){
	FILE* file = fopen(AUTA2_FILENAME, "ab");
	fwrite(&a.delkaNazvu, sizeof(int), 1, file);
	fwrite(a.nazev, 1, a.delkaNazvu, file);
	fwrite(&a.rokVyroby, sizeof(int), 1, file);
	fclose(file);
}

T_auto noveAuto(int rokVyroby, const char* nazev){
	T_auto temp;
	
	temp.delkaNazvu = strlen(nazev) + 1;
	temp.nazev = (char*)malloc(temp.delkaNazvu);
	strcpy(temp.nazev, nazev);
	temp.rokVyroby = rokVyroby;
	
	return temp;
}

void vypisAuta(T_auto a){
	printf("%s, rok %d\n", a.nazev, a.rokVyroby);
}

void vypsatAutaZeSouboru(){
	FILE* file = fopen(AUTA2_FILENAME, "rb");
	if(!file){
		printf("Soubor nenalezen, pridejte jedno auto pro vytvoreni\n");
		return;
	}
	T_auto temp;
	
	while(fread(&temp.delkaNazvu, sizeof(int), 1, file)){
		temp.nazev = (char*)malloc(temp.delkaNazvu);
		fread(temp.nazev, 1, temp.delkaNazvu, file);
		fread(&temp.rokVyroby, sizeof(int), 1, file);
		vypisAuta(temp);
		free(temp.nazev);
	}
	
	fclose(file);
}

void sortByYear(char way){
	FILE* file = fopen(AUTA2_FILENAME, "rb");
	if(!file){
		printf("Soubor nenalezen, pridejte jedno auto pro vytvoreni\n");
		return;
	}
	T_auto temp;
	T_auto* auta = (T_auto*)malloc(sizeof(T_auto));
	int count = 0;
	int i, j, maxormin;
	while(fread(&temp.delkaNazvu, sizeof(int), 1, file)){
		temp.nazev = (char*)malloc(temp.delkaNazvu);
		fread(temp.nazev, 1, temp.delkaNazvu, file);
		fread(&temp.rokVyroby, sizeof(int), 1, file);
		count++;
	}
	if(way){
	}
	else{
		
	}
	free(auta);
	fclose(file);
}
