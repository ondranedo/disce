#ifndef AUTA2
#define AUTA2

#define AUTA2_FILENAME "auta.adam"

typedef struct{
	int rokVyroby;
	char* nazev;
	int delkaNazvu;
} T_auto;

void vypisAuta(T_auto a);
T_auto noveAuto(int rokVyroby, const char* nazev);
void pridatAutoDoSouboru(T_auto a);
void vypsatAutaZeSouboru();
void sortByYear(char way);

#endif
